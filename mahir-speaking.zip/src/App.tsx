import { useState, useRef } from 'react';
import { FloatingAssistant } from './components/FloatingAssistant';
import { MashiraAssistant } from './components/MashiraAssistant';

export default function App() {
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const floatingButtonRef = useRef<HTMLButtonElement | null>(null);

  return (
    <div className="min-h-screen bg-[#EEF3F7] text-[#0F172A] font-sans antialiased selection:bg-[#0F9F95] selection:text-white flex flex-col justify-between p-4 sm:p-6">
      {/* Top Left Environment Badge */}
      <header className="flex items-center justify-between max-w-7xl w-full mx-auto">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#0F9F95] animate-pulse" />
          <span className="text-xs font-semibold text-[#64748B] tracking-wide select-none">
            Mashira AI Assistant — Chat & Voice Coach Preview
          </span>
        </div>
      </header>

      {/* Clean Blank Canvas Area for Testing Panel & Floating Button */}
      <main className="flex-1 flex flex-col items-center justify-center text-center max-w-md mx-auto py-12 px-4 space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-[#0F9F95]/10 text-[#0F9F95] flex items-center justify-center font-black text-xl mb-1 select-none">
          M
        </div>
        <h1 className="text-base font-bold text-[#0F172A]">
          Area Pengujian Mashira AI Assistant
        </h1>
        <p className="text-xs text-[#64748B] leading-relaxed">
          Tekan tombol melayang di kanan bawah untuk membuka panel Mashira (Chat Tutor & Voice Coach).
        </p>
      </main>

      {/* Footer minimal info */}
      <footer className="text-center text-[11px] text-[#64748B] max-w-7xl w-full mx-auto select-none">
        Dioptimalkan untuk Google Chrome & Microsoft Edge via Web Speech API
      </footer>

      {/* Floating Button & Assistant Floating Panel */}
      <FloatingAssistant
        isOpen={isPanelOpen}
        onToggle={() => setIsPanelOpen(!isPanelOpen)}
        buttonRef={floatingButtonRef}
      />

      <MashiraAssistant
        isOpen={isPanelOpen}
        onClose={() => setIsPanelOpen(false)}
        floatingButtonRef={floatingButtonRef}
      />
    </div>
  );
}
