import React from 'react';
import { Mic } from 'lucide-react';

interface FloatingAssistantProps {
  isOpen: boolean;
  onToggle: () => void;
  buttonRef?: React.RefObject<HTMLButtonElement | null>;
}

export const FloatingAssistant: React.FC<FloatingAssistantProps> = ({
  isOpen,
  onToggle,
  buttonRef
}) => {
  return (
    <div className="fixed bottom-5 right-5 z-40 flex items-center gap-2 group">
      {/* Tooltip Label */}
      <div
        id="floating-tooltip"
        role="tooltip"
        className="hidden sm:flex items-center gap-1.5 bg-[#071B34] text-white text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none select-none"
      >
        <span>Buka Mashira Assistant</span>
      </div>

      {/* 64px Circular Floating Button */}
      <button
        ref={buttonRef}
        onClick={onToggle}
        aria-label="Buka Mashira Assistant"
        aria-describedby="floating-tooltip"
        aria-expanded={isOpen}
        className={`relative flex items-center justify-center w-16 h-16 rounded-full shadow-xl transition-all duration-300 cursor-pointer focus:outline-hidden focus:ring-4 focus:ring-[#0F9F95]/50 ${
          isOpen
            ? 'bg-[#071B34] text-white scale-95 ring-2 ring-white shadow-teal-500/20'
            : 'bg-[#0F9F95] hover:bg-[#0b827a] text-white hover:-translate-y-[3px] active:scale-95 shadow-teal-700/25'
        }`}
      >
        {/* Soft Idle Breathing Animation (respects prefers-reduced-motion) */}
        {!isOpen && (
          <span className="absolute inset-0 rounded-full bg-[#0F9F95] opacity-25 motion-safe:animate-ping pointer-events-none" />
        )}

        {/* Center Avatar 'M' */}
        <span className="text-xl font-black tracking-tight select-none">M</span>

        {/* Small Microphone Overlay Badge */}
        <span className="absolute -bottom-0.5 -right-0.5 bg-[#071B34] text-white p-1.5 rounded-full ring-2 ring-white shadow-xs">
          <Mic className="w-3.5 h-3.5 text-teal-300" />
        </span>

        {/* Online Indicator Dot */}
        <span className="absolute top-0.5 right-0.5 w-3 h-3 rounded-full bg-emerald-400 ring-2 ring-white" />
      </button>
    </div>
  );
};
